package com.example.cew_cep_cs031_cs010_cs006;

import java.util.ArrayList;

public class books_description {

    public books_description(){

    }

    public  String[] get_description(){
        String[] des = {"Harry Potter and the Philosopher's Stone is a fantasy novel." +
                "The first novel in the Harry Potter series and Rowling's debut novel," +
                "it follows Harry Potter, a young wizard who discovers his magical heritage " +
                "on his eleventh birthday,when he receives a letter of acceptance to Hogwarts " +
                "School of Witchcraft and Wizardry. and the Journey Begins.\n\n" +
                "The book was first published in the United Kingdom on 26 June 1997 by Bloomsbury." +
                "The novel has sold in excess of 120 million copies, " +
                "making it the third best-selling novel of all time. ",

                "Harry Potter and the Chamber of Secrets is a fantasy novel written by British author " +
                        "J.K. Rowling and the second novel in the Harry Potter series. " +
                        "The plot follows Harry's second year at Hogwarts School of Witchcraft and Wizardry, " +
                        "during which a series of messages on the walls of the school's corridors " +
                        "warn that the \"Chamber of Secrets\" has been opened and that the " +
                        "\"heir of Slytherin\" would kill all pupils w" +
                        "ho do not come from all-magical families.\n\nThe book was published in the " +
                        "United Kingdom on 2 July 1998 by Bloomsbury and later in the United States " +
                        "on 2 June 1999 by Scholastic Inc.",

                "Harry Potter and the Prisoner of Azkaban is a fantasy novel written by British "+
                        "author J.K. Rowling and is the third in the Harry Potter series. " +
                        "The book follows Harry Potter, a young wizard, in his third year " +
                        "at Hogwarts School of Witchcraft and Wizardry. Along with friends " +
                        "Ronald Weasley and Hermione Granger, Harry investigates Sirius Black, " +
                        "an escaped prisoner from Azkaban, the wizard prison, believed to be " +
                        "one of Lord Voldemort's old allies.\n\nThe book was published in the United" +
                        " Kingdom on 8 July 1999 by Bloomsbury and in the United States on 8 " +
                        "September 1999 by Scholastic, Inc.The film adaptation of the novel was " +
                        "released in 2004, grossing more than $796 million and earning critical " +
                        "acclaim.",

                "Amara the Brave is a novel written by Matt Zhang.",

                "The Book of Warlock a novel written by J.D. Oliva.he US Military has finally developed " +
                        "the perfect weapon and it’s gone missing.\n\n" +
                        "Desperate, they have reached out assassin Ethan Jericho to take out the man" +
                        " responsible: Crawford Lockhart.\n\n" +
                        "Fifteen years ago, Jericho knew Lockhart by another name—Warlock. As " +
                        "Jericho’s former mentor, they were an inseparable team until Jericho " +
                        "ruined it all. Now, Jericho faces a heart-wrenching offer: kill Warlock, " +
                        "and the government will clear his record.\n\n" +
                        "But when Jericho confronts his old friend, " +
                        "he discovers Warlock’s weapon is a five-year-old girl" +
                        "blessed with an unholy ability. And worse, Jericho isn’t the only " +
                        "one tracking them down.",


                "Catching Fire is a 2009 science fiction young adult novel by the American novelist " +
                        "Suzanne Collins, the second book in The Hunger Games series. As the sequel " +
                        "to the 2008 bestseller The Hunger Games, it continues the story of Katniss " +
                        "Everdeen and the post-apocalyptic nation of Panem. Following the events of " +
                        "the previous novel, a rebellion against the oppressive Capitol has begun, " +
                        "and Katniss and fellow tribute Peeta Mellark are forced to return to the " +
                        "arena in a special edition of the Hunger Games.\n\nThe book was first " +
                        "published on September 1, 2009, by Scholastic, in hardcover, and was later " +
                        "released in ebook and audiobook format. Catching Fire received mostly " +
                        "positive reviews. The book has sold more than 19 million copies in the U.S." +
                        " alone.",

                "The Dreaming Arts a book written by Tom Maloney.The Dreaming Arts is a book" +
                        " about sleep and dreams and how to use them as a vehicle for personal " +
                        "evolution.\n\nAll ages except children, men and women. People that are into" +
                        " health, wellness, non-mainstream, alternative, independent thinkers, " +
                        "open minded, and intelligent.",

                "Robin MacArthur’s newest book is a meditation on the connections between adulthood " +
                        "and the land of ancestors. “Heart Spring Mountain” explores the buried " +
                        "emotions that surface when a woman, Vale, returns to her hometown after her" +
                        " drug-addicted mother, Bonnie, disappears in a hurricane. The story slowly " +
                        "weaves through several generations of the same family, exposing how the past" +
                        " influences the present. Although MacArthur has written a narrative filled " +
                        "with compelling reflections on the past’s impact and global warming’s " +
                        "repercussions, the present plot offers very little action. This is a novel " +
                        "more focused on thought than experience.",


                        "The Author of the Book is JK Rowling. It was released in 2018.",
                        "The Author of the Book is JK Rowling. It was released in 2019.",
                        "The Author of the Book is JK Rowling. It was released in 2020.",
                        "The Author of the Book is JK Rowling. It was released in 2021.",
                        "The Author of the Book is JK Rowling. It was released in 2022."};
        return des;
    }
}
