package com.example.cew_cep_cs031_cs010_cs006;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class books extends AppCompatActivity {
    RecyclerView recyclerView;
    TextView display_name;
    String books_title[];
    //int book_images[] = {R.drawable.harry1, R.drawable.harry2, R.drawable.harry3};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_books);
        display_name = findViewById(R.id.display);
        recyclerView =findViewById(R.id.recyclerView);

        Intent getName =  getIntent();
        String user = getName.getStringExtra("login_name");
        display_name.setText("Welcome " + user);

        books_title = getResources().getStringArray(R.array.Book_Name);

        recycling_books listing_books = new recycling_books(books.this, books_title);
        recyclerView.setAdapter(listing_books);
        recyclerView.setLayoutManager(new LinearLayoutManager(books.this));
    }
}